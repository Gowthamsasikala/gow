export class userRegister  {

    first:string;
    last:String;
    dob:String;
    Address:String;
    num:String;
    email:String;
    qualify:String;
    Salary:String;
    PAN:String;
    TOE:String;
    Male:String;
    Female:String;
    Question:String;
    Ans:String;
    EMPT:String;
}

export class policyRegister{
    Pname:String;
Sdate:String;
DIY:String;
InitialDeposit:String;
Cname:String;
PType:String;
Utype:String;
TPY:String;
TAmount:String;
Interest:String;
}

export class editPolicy{
    Pname:String;
    DIY:String;
    PType:String;
    TAmount:String;
    
}

export class searchPolicy{
    NOY:String;
    Cname:String;
    PType:String;
    PID:String;
    Pname:String;
}

export class UserAdmin{
    UserType:String;
    Password:String;
}